//Musharib
//i201764
//Assignment 6
#include <iostream> 
using namespace std;
int main (){
	int numbers[14];
	int size;
	int n;
	int low;
	int high;
	int x;
	
    cout<<"Enter 15 elements: "<<endl; 
	for(int i=0;i<15;i++)
	{
	cout<<"Enter the value ["<<i<<"]: ";
	cin>>numbers[i];
	}
	cout<<"Enter n: ";
	cin>>n;
	
       
}
